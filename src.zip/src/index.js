import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
// import './index.css';
// import './Web.css';
import App from './App';
// import reportWebVitals from './reportWebVitals';
// function Car(props){
//     return<li>I am a {props.brand}</li>;
// }
// function Garage(){
//     const cars=['Ford','BMW','Audi'];
//     return (
//         <>
//         <h1>Who lives in garage???</h1>
//         <ul>
//             {cars.map((car)=><Car brand={car}/>)}
//         </ul>
//         </>
//     );
// }
ReactDOM.render(
    //  <Garage/>,
    <BrowserRouter>
    <App/>
    </BrowserRouter>,
     document.getElementById('root')
  );
  
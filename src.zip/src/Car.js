function Car(){

    return <h1>HI, this is a Car!!!!</h1>;
}
function Car2(){

    return <h1>HI, this is a Car2!!!!</h1>;
}

export default Car2;
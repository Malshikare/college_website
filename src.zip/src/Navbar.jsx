import React from 'react'
import { NavLink } from 'react-router-dom'
import "./Navbar.css"
export default function Navbar() {
  return (
    <div>
      <div className=" p-3 bg-white class-for-width"
      // style={{ width: "280px" }}
      >
        <a href="/" className="d-flex  align-items-center pb-3 mb-3 link-dark text-decoration-none border-bottom">
          <svg className="bi me-2" width="30" height="24">
            {/* <use xlink:href="#bootstrap"/> */}
          </svg>
          <span className="fs-5 fw-semibold align">DEPARTMENT</span>
        </a>
        <ul className="list-unstyled ps-0 align">
          <li className="mb-1 space-class">
            <button className="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#comp-collapse" aria-expanded="false">
              <NavLink to="/department/comp" className="text-dec">Computer Engineering</NavLink>
            </button>
            <div className="collapse" id="comp-collapse">
              <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                <li><NavLink to="/department/comp/about" className=" rounded text-dec">About</NavLink></li>
                {/* <li><NavLink className="link-dark rounded">Regular Staff and Faculty</NavLink></li>
            <li><NavLink className="link-dark rounded">Laboratories</NavLink></li>
            <li><NavLink className="link-dark rounded">Students Organizations</NavLink></li>
            <li><NavLink className="link-dark rounded">Research</NavLink></li>
            <li><NavLink className="link-dark rounded">Events</NavLink></li>
            <li><NavLink className="link-dark rounded">Syllabus</NavLink></li>
            <li><NavLink className="link-dark rounded">Time Table</NavLink></li>
            <li><NavLink className="link-dark rounded">Achievements</NavLink></li>
            <li><NavLink className="link-dark rounded">Notices</NavLink></li>
            <li><NavLink className="link-dark rounded">Gallery</NavLink></li>  */}
              </ul>
            </div>
          </li>
          <li className="mb-1 space-class">
            <button className="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#entc-collapse" aria-expanded="false">
              <NavLink to="/department/entc/about" className="text-dec">Electronics and Telecommunication Engineering</NavLink>
            </button>
            <div className="collapse" id="entc-collapse">
              <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                <li><NavLink to="/department/entc/about" className="link-dark rounded">About</NavLink></li>
                <li><NavLink to="/department/entc/staff" className="link-dark rounded">Regular Staff and Faculty</NavLink></li>
                <li><NavLink to="/department/entc/lab" className="link-dark rounded">Laboratories</NavLink></li>
                <li><NavLink to="/department/entc/organizations" className="link-dark rounded">Students Organizations</NavLink></li>
                <li><NavLink to="/department/entc/research" className="link-dark rounded">Research</NavLink></li>
                <li><NavLink to="/department/entc/events" className="link-dark rounded">Events</NavLink></li>
                <li><NavLink to="/department/entc/syllabus" className="link-dark rounded">Syllabus</NavLink></li>
                <li><NavLink to="/department/entc/timetable" className="link-dark rounded">Time Table</NavLink></li>
                <li><NavLink to="/department/entc/achievements" className="link-dark rounded">Achievements</NavLink></li>
                <li><NavLink to="/department/entc/notices" className="link-dark rounded">Notices</NavLink></li>
                <li><NavLink to="/department/entc/gallery" className="link-dark rounded">Gallery</NavLink></li>
              </ul>
            </div>
          </li>
          <li className="mb-1 space-class">
            <button className="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#mech-collapse" aria-expanded="false">
              <NavLink to="/department/entc/about" className="text-dec">Mechanical Engineering</NavLink>
            </button>
            <div className="collapse" id="mech-collapse">
              <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                <li><a href="#" className="link-dark rounded">About</a></li>
                <li><a href="#" className="link-dark rounded">Regular Staff and Faculty</a></li>
                <li><a href="#" className="link-dark rounded">Laboratories</a></li>
                <li><a href="#" className="link-dark rounded">Students Organizations</a></li>
                <li><a href="#" className="link-dark rounded">Research</a></li>
                <li><a href="#" className="link-dark rounded">Events</a></li>
                <li><a href="#" className="link-dark rounded">Syllabus</a></li>
                <li><a href="#" className="link-dark rounded">Time Table</a></li>
                <li><a href="#" className="link-dark rounded">Achievements</a></li>
                <li><a href="#" className="link-dark rounded">Notices</a></li>
                <li><a href="#" className="link-dark rounded">Gallery</a></li>
              </ul>
            </div>
          </li>
          <li className="mb-1 space-class">
            <button className="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#auto-collapse" aria-expanded="false">
              <NavLink to="/department/entc/about" className="text-dec">Automobile Engineering</NavLink>
            </button>
            <div className="collapse" id="auto-collapse">
              <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                <li><a href="#" className="link-dark rounded">About</a></li>
                <li><a href="#" className="link-dark rounded">Regular Staff and Faculty</a></li>
                <li><a href="#" className="link-dark rounded">Laboratories</a></li>
                <li><a href="#" className="link-dark rounded">Students Organizations</a></li>
                <li><a href="#" className="link-dark rounded">Research</a></li>
                <li><a href="#" className="link-dark rounded">Events</a></li>
                <li><a href="#" className="link-dark rounded">Syllabus</a></li>
                <li><a href="#" className="link-dark rounded">Time Table</a></li>
                <li><a href="#" className="link-dark rounded">Achievements</a></li>
                <li><a href="#" className="link-dark rounded">Notices</a></li>
                <li><a href="#" className="link-dark rounded">Gallery</a></li>
              </ul>
            </div>
          </li>
          <li className="mb-1 space-class">
            <button className="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#civil-collapse" aria-expanded="false">
              <NavLink to="/department/entc/about" className="text-dec">Civil Engineering</NavLink>
            </button>
            <div className="collapse" id="civil-collapse">
              <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                <li><a href="#" className="link-dark rounded">About</a></li>
                <li><a href="#" className="link-dark rounded">Regular Staff and Faculty</a></li>
                <li><a href="#" className="link-dark rounded">Laboratories</a></li>
                <li><a href="#" className="link-dark rounded">Students Organizations</a></li>
                <li><a href="#" className="link-dark rounded">Research</a></li>
                <li><a href="#" className="link-dark rounded">Events</a></li>
                <li><a href="#" className="link-dark rounded">Syllabus</a></li>
                <li><a href="#" className="link-dark rounded">Time Table</a></li>
                <li><a href="#" className="link-dark rounded">Achievements</a></li>
                <li><a href="#" className="link-dark rounded">Notices</a></li>
                <li><a href="#" className="link-dark rounded">Gallery</a></li>
              </ul>
            </div>
          </li>
          <li className="mb-1 space-class">
            <button className="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#instru-collapse" aria-expanded="false">
              <NavLink to="/department/entc/about" className="text-dec">Instrumentation and Control Engineering</NavLink>
            </button>
            <div className="collapse" id="instru-collapse">
              <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                <li><a href="#" className="link-dark rounded">About</a></li>
                <li><a href="#" className="link-dark rounded">Regular Staff and Faculty</a></li>
                <li><a href="#" className="link-dark rounded">Laboratories</a></li>
                <li><a href="#" className="link-dark rounded">Students Organizations</a></li>
                <li><a href="#" className="link-dark rounded">Research</a></li>
                <li><a href="#" className="link-dark rounded">Events</a></li>
                <li><a href="#" className="link-dark rounded">Syllabus</a></li>
                <li><a href="#" className="link-dark rounded">Time Table</a></li>
                <li><a href="#" className="link-dark rounded">Achievements</a></li>
                <li><a href="#" className="link-dark rounded">Notices</a></li>
                <li><a href="#" className="link-dark rounded">Gallery</a></li>
              </ul>
            </div>
          </li>
        </ul>
      </div>

    </div>
  )
};

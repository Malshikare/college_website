import React from "react";
import { NavLink } from "react-router-dom";
import "./Department.css";
function Department(){
    return(
        <div className="department">
           <NavLink to="/department/civil">Civil Engineering</NavLink>
           <NavLink to="/department/comp">Computer Engineering</NavLink>
           <NavLink to="/department/entc">Elecronics and Telecommunication Engineering</NavLink>
           <NavLink to="/department/instru">Instrumentation and Control Engineering</NavLink>
           <NavLink to="/department/auto">Automobile Engineering</NavLink>
           <NavLink to="/department/mech">Mechanical Engineeering</NavLink>
        </div>
    )
};
export default Department;
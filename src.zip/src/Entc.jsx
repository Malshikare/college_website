import React from "react";
import Navbar from "./Navbar";
// import hodImage from "file:///home/spielerin/Pictures/cat.webp";
import "./Entc.css";
const Entc = () => {
  return (
    <div className="entc-wrap ">
      <div>
        <Navbar />
      </div>
      <div className="comtainer emp-profile">
        <form method="">
          <div className="main">
            <h1>Electronics and Telecommunication Department</h1>
            {/* <hr></hr> */}
            {/* <h2>Electronics and Telecommunication Department</h2> */}

            <div className="info">
              <div className="para">
                <b>Department</b>
                <hr />
                <p>
                  The department of Electronics and Telecommunication was
                  established in 2009-10. Since its commencement, the primary
                  objective of the department has been to impart quality
                  education, training and research at the undergraduate in
                  various areas of Electronics and Telecommunication Engineering
                  with broad emphasis on design aspects of electronic systems.
                </p>
                <p>
                  The Department has always been on a high growth path and has
                  experienced and dedicated faculty with a strong commitment to
                  engineering education. To keep pace with the current
                  technological trends, all the undergraduate curricula have
                  been upgraded by Savitribai Phule Pune University. The course
                  offered is well known for its applied nature including a
                  strong laboratory component and considerable project work. It
                  is designed for students who wish to become professional
                  engineer in the fields of Electronics and Telecommunication
                  engineering. The course emphasizes the importance of
                  communication and electronics systems and the applications of
                  principles, developed in the course to the solution of
                  significant practical problems.
                </p>
                {/* </div>
<br />
<div className="para"> */}
                {/* <b>Laboratories</b>
<hr /> */}
                <p>
                  Laboratory facilities are utilized by students for the
                  extensive project work that is a feature of the course. PC and
                  workstation based computing laboratories provide tools for
                  electronic circuit simulation and computer-aided design work.
                </p>
                {/* </div>
<br />

<br />
<div className="para"> */}
                <br />
                <p>
                  The department focuses on preparing its students to meet new
                  Industry challenges and making them aware of the recent
                  advances in the technological field by emphasizing on
                </p>
                <ul>
                  <li>
                    A strong technical training in modern electronics technology
                  </li>
                  <li>
                    Skills in analysing and design of microelectronic circuits
                    and system
                  </li>
                  <li>Latest trends in simulation</li>
                  <li>Advanced computer networking</li>
                  <li>
                    Practical skills in, Image processing, VLSI Design, Fiber
                    Optic Communication and Advance Communication
                  </li>
                </ul>
                <br />
                <p>
                  In addition to the academic achievements, the students have
                  been demonstrating skills in various extracurricular
                  activities including paper Presentations, sports, etc. They
                  have been conducting various activities like personality
                  development programmes, group discussions, workshops, etc.
                  Strengths:
                </p>
                <ul>
                  <li> Huge Infrastructure</li>
                  <li>Experienced and Qualified Faculty Members</li>
                  <li>Meritorious Stuff</li>
                  <li>Well Equipped Laboratories with Latest Equipment’s</li>
                  <li>Excellent Academic Records</li>
                  <li>
                    Enriched Tradition of Co-curricular and Extra-curricular
                    activities
                  </li>
                </ul>
              </div>
            </div>

            <div className="dept">
              <table className="table">
                <tr>
                  <td colSpan="2" id="uprow">
                    <b>Department Profile</b>
                  </td>
                </tr>
                <tr>
                  <td>Establishment Year</td>
                  <td>2009-2010</td>
                </tr>
                <tr>
                  <td>Department Location</td>
                  <td>(Location here)</td>
                </tr>
                <tr>
                  <td>Intake</td>
                  <td>180</td>
                </tr>
                <tr>
                  <td>Total Number of Classrooms</td>
                  <td>4</td>
                </tr>
                <tr>
                  <td>Total Number of Laboratories</td>
                  <td>11</td>
                </tr>
              </table>

              <br />
              <br />
              <table className="table">
                <tr>
                  <td colSpan="2" id="uprow">
                    <b>Under Graduate Program</b>
                  </td>
                </tr>
                <tr>
                  <td>Programme Name</td>
                  <td> B.E. Electronics and Telecommunication Engineering</td>
                </tr>
                <tr>
                  <td>Nature of Program</td>
                  <td>Full Time</td>
                </tr>
                <tr>
                  <td>Duration</td>
                  <td>4 Years</td>
                </tr>
                <tr>
                  <td>Current Intake</td>
                  <td>240</td>
                </tr>
              </table>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Entc;

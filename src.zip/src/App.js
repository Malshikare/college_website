// import logo from './logo.svg';
import './App.css';
import React from 'react'
import Navbar from './Navbar';
import {Route, Routes} from "react-router-dom";
import Web from "./Web";

// import Department from "./Department";
// import Civil from "./Civil";
// import Comp from "./Comp";
// import About from './About';
import Entc from "./Entc";
// import Instru from "./Instru";
// import Auto from "./Auto";
// import Mech from "./Mech";

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

function App(){
  return(
    <>
    
      <Routes>
        <Route path="/" element={<Navbar/>}/>
        {/* <Route path="/department" element={<Department/>}/> */}
        {/* <Route path="/department/comp" element={<Comp/>}/> */}
        {/* <Route path="/department/comp/about" element={<About/>}/> */}
        <Route path="/department/entc/about" element={<Entc/>}/>
        {/* <Route path="/department/instru" element={<Instru/>}/>
        <Route path="/department/auto" element={<Auto/>}/>
        <Route path="/department/mech" element={<Mech/>}/>  */}


      </Routes>
      
      {/* <Department/> */}
      <Web/>
    </>
  )
}
export default App;

import React from 'react'
import { NavLink } from 'react-router-dom'
import "./Navbar.css"

export default function Comp() {
    return (
        <div>
           Computer Department
        </div>
    )
}

